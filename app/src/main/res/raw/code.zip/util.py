
def test(x):
    x = x + 1
    return x